<?php

/* Config data from twitter registered application. */
define('CONSUMER_KEY', 'k1BR3HBYnFtwFSwg0c8UA');
define('CONSUMER_SECRET', '2xAivaOWKtEbpQRH5K9ee8PNp5mqUOnygCyqN4GDgrk');
define('OAUTH_CALLBACK', 'http://www.montealquila.com.ar/api/service/Callback.php');

?>
